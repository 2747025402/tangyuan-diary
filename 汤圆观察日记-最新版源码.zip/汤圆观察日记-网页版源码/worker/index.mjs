const COOKIE = "__Host-care";
const UUID = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
const validId = new RegExp("^" + UUID + "$");
const mediaRoute = new RegExp("^/api/media/(" + UUID + ")/(" + UUID + ")$");
const entryRoute = new RegExp("^/api/entries/(" + UUID + ")$");
const kinds = new Set(["food", "medicine", "urine", "stool", "condition", "weight", "visit", "other"]);
const mediaTypes = new Set([
  "image/jpeg", "image/png", "image/webp", "image/gif", "image/heic", "image/heif", "image/avif",
  "video/mp4", "video/quicktime", "video/webm", "video/x-m4v",
]);
const privateHeaders = {
  "Cache-Control": "private, no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
};

function json(data, status = 200, headers = {}) {
  return Response.json(data, { status, headers: { ...privateHeaders, ...headers } });
}

function fail(message, status = 400) {
  return json({ error: message }, status);
}

function accessFor(key, env) {
  if (!/^(?:[A-Za-z0-9_-]{22}|[A-Za-z0-9_-]{43})$/.test(key ?? "")) return null;
  // The compact link retains 132 bits from the original random key.
  if (key === env.OWNER_KEY?.slice(0, key.length)) return "owner";
  if (key === env.FRIEND_KEY?.slice(0, key.length)) return "friend";
  if (key === env.SHARED_KEY?.slice(0, key.length)) return "shared";
  return null;
}

function storageKey(author, entryId, mediaId, uploadRevision) {
  const prefix = author + "/" + entryId + "/";
  return uploadRevision ? prefix + uploadRevision + "/" + mediaId : prefix + mediaId;
}

const revisionIsValid = value => Number.isSafeInteger(value) && value > 0;
const staleEntry = () => fail("这条记录已被修改，请重新打开后再试。", 409);

async function readJson(request) {
  if (!request.headers.get("content-type")?.startsWith("application/json")) return null;
  const length = Number(request.headers.get("content-length"));
  if (!Number.isInteger(length) || length < 1 || length > 64 * 1024) return null;
  try { return await request.json(); } catch { return null; }
}

async function upload(request, env, author, entryId, fileId) {
  const type = request.headers.get("content-type");
  const length = Number(request.headers.get("content-length"));
  if (!mediaTypes.has(type)) return fail("请选择支持的照片或视频格式。", 415);
  const photo = type.startsWith("image/");
  const maxMB = photo ? 10 : 25;
  if (!Number.isInteger(length) || length < 1 || length > maxMB * 1024 * 1024) {
    return fail(photo ? "照片每张不超过 10 MB。" : "视频每个不超过 25 MB。", 413);
  }
  const name = (request.headers.get("x-file-name") || "").slice(0, 1400);
  const requestedRevision = request.headers.get("X-Entry-Revision");
  const revision = requestedRevision === null ? null : Number(requestedRevision);
  const existing = await env.DB.prepare("SELECT author, revision FROM entries WHERE id = ?").bind(entryId).first();
  if (revision === null && existing) return fail("这条记录已保存。", 409);
  if (revision !== null) {
    if (!revisionIsValid(revision)) return fail("记录版本无效。");
    if (!existing) return fail("这条记录已删除。", 404);
    if (existing.revision !== revision) return staleEntry();
  }
  const bytes = await request.arrayBuffer();
  if (bytes.byteLength !== length) return fail("文件上传不完整，请重试。");
  const key = storageKey(existing?.author ?? author, entryId, fileId, revision);
  await env.BUCKET.put(key, bytes, {
    httpMetadata: { contentType: type },
    customMetadata: { name },
    onlyIf: { etagDoesNotMatch: "*" },
  });
  return json({ id: fileId }, 201);
}

function readRecord(data) {
  if (!data || !kinds.has(data.kind) ||
      typeof data.happenedAt !== "string" || typeof data.detail !== "string" ||
      typeof data.note !== "string" || !Array.isArray(data.files) || data.files.length > 4 ||
      data.files.some(id => typeof id !== "string" || !validId.test(id)) ||
      new Set(data.files).size !== data.files.length) return fail("请检查记录中的内容。");

  const detail = data.detail.trim();
  const note = data.note.trim();
  const happenedAt = new Date(data.happenedAt);
  const weight = data.kind === "weight" ? data.weight : null;
  const medicineName = data.kind === "medicine" && typeof data.medicineName === "string" ? data.medicineName.trim() : "";
  const medicineDose = data.kind === "medicine" && typeof data.medicineDose === "string" ? data.medicineDose.trim() : "";
  const medicineMethod = data.kind === "medicine" && typeof data.medicineMethod === "string" ? data.medicineMethod.trim() : "";
  const nextMedicationAt = data.kind === "medicine" && data.nextMedicationAt ? new Date(data.nextMedicationAt) : null;
  if (!Number.isFinite(happenedAt.getTime()) || detail.length > 2000 || note.length > 3000) {
    return fail("请检查时间或缩短记录内容。");
  }
  if (medicineName.length > 120 || medicineDose.length > 120 || medicineMethod.length > 120 ||
      (nextMedicationAt && !Number.isFinite(nextMedicationAt.getTime()))) return fail("请检查用药信息。");
  if (data.kind === "weight" && (!Number.isFinite(weight) || weight <= 0 || weight > 500)) {
    return fail("请输入有效的体重（公斤）。");
  }
  if (!detail && !note && weight === null && !medicineName && !medicineDose && !medicineMethod && !data.files.length) {
    return fail("请填写内容或添加附件。");
  }

  return {
    kind: data.kind, happenedAt: happenedAt.toISOString(), detail, note, weight, files: data.files,
    medicineName: medicineName || null, medicineDose: medicineDose || null, medicineMethod: medicineMethod || null,
    nextMedicationAt: nextMedicationAt?.toISOString() ?? null,
  };
}

async function loadMedia(env, author, entryId, ids, existing = [], revision = null) {
  const previous = new Map(existing.map(file => [file.id, file]));
  return Promise.all(ids.map(async id => {
    if (previous.has(id)) return previous.get(id);
    const object = await env.BUCKET.head(storageKey(author, entryId, id, revision));
    if (!object) return null;
    let name;
    try { name = decodeURIComponent(object.customMetadata?.name || ""); } catch { name = ""; }
    const media = { id, type: object.httpMetadata.contentType, name: name.slice(0, 150), size: object.size };
    if (revision !== null) media.uploadRevision = revision;
    return media;
  }));
}

async function createEntry(request, env, author) {
  const data = await readJson(request);
  if (typeof data?.id !== "string" || !validId.test(data.id)) return fail("记录 ID 无效。");
  const record = readRecord(data);
  if (record instanceof Response) return record;
  const existing = await env.DB.prepare(entryQuery + " WHERE id = ?").bind(data.id).first();
  if (existing) return existing.author === author ? json({ entry: parseEntry(existing) }) : fail("记录 ID 已存在。", 409);
  const media = await loadMedia(env, author, data.id, record.files);
  if (media.some(file => !file)) return fail("还有附件没有上传成功，请重试。");

  await env.DB.prepare(
    "INSERT INTO entries (id, author, kind, happened_at, detail, note, weight, media, medicine_name, medicine_dose, medicine_method, next_medication_at, updated_at, updated_by) " +
    "SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? " +
    "WHERE NOT EXISTS (SELECT 1 FROM entry_changes WHERE entry_id = ?) ON CONFLICT(id) DO NOTHING",
  ).bind(
    data.id, author, record.kind, record.happenedAt, record.detail, record.note, record.weight, JSON.stringify(media),
    record.medicineName, record.medicineDose, record.medicineMethod, record.nextMedicationAt,
    new Date().toISOString(), author, data.id,
  ).run();
  const saved = await env.DB.prepare(entryQuery + " WHERE id = ?").bind(data.id).first();
  return saved?.author === author ? json({ entry: parseEntry(saved) }, 201) : fail("记录 ID 已存在。", 409);
}

const entryColumns = "id, author, kind, happened_at AS happenedAt, detail, note, weight, media, revision, " +
  "medicine_name AS medicineName, medicine_dose AS medicineDose, medicine_method AS medicineMethod, " +
  "next_medication_at AS nextMedicationAt, updated_at AS updatedAt, updated_by AS updatedBy";
const entryQuery = "SELECT " + entryColumns + " FROM entries";
const parseEntry = row => ({ ...row, media: JSON.parse(row.media) });

async function cleanMedia(env, entry, retained = []) {
  const keep = new Set(retained.map(file => file.id));
  const keys = entry.media.filter(file => !keep.has(file.id))
    .map(file => storageKey(entry.author, entry.id, file.id, file.uploadRevision));
  if (keys.length) await env.BUCKET.delete(keys).catch(() => console.error("Attachment cleanup failed"));
}

async function changeEntry(request, env, id, actor) {
  const data = await readJson(request);
  if (!revisionIsValid(data?.revision)) return fail("记录版本无效。");
  const row = await env.DB.prepare(entryQuery + " WHERE id = ?").bind(id).first();
  if (!row) return fail("这条记录已删除。", 404);
  if (row.revision !== data.revision) return staleEntry();
  const previous = parseEntry(row);

  if (request.method === "DELETE") {
    const deleted = await env.DB.prepare("DELETE FROM entries WHERE id = ? AND revision = ? RETURNING id")
      .bind(id, data.revision).first();
    if (!deleted) return staleEntry();
    await cleanMedia(env, previous);
    return json({ id });
  }

  const record = readRecord(data);
  if (record instanceof Response) return record;
  const media = await loadMedia(env, row.author, id, record.files, previous.media, data.revision);
  if (media.some(file => !file)) return fail("还有附件没有上传成功，请重试。");
  const saved = await env.DB.prepare(
    "UPDATE entries SET kind = ?, happened_at = ?, detail = ?, note = ?, weight = ?, media = ?, " +
    "medicine_name = ?, medicine_dose = ?, medicine_method = ?, next_medication_at = ?, " +
    "updated_at = ?, updated_by = ?, revision = revision + 1 " +
    "WHERE id = ? AND revision = ? RETURNING " + entryColumns,
  ).bind(
    record.kind, record.happenedAt, record.detail, record.note, record.weight, JSON.stringify(media),
    record.medicineName, record.medicineDose, record.medicineMethod, record.nextMedicationAt,
    new Date().toISOString(), actor, id, data.revision,
  ).first();
  if (!saved) return staleEntry();
  await cleanMedia(env, previous, media);
  return json({ entry: parseEntry(saved) });
}

async function listEntries(env, url) {
  const changes = url.searchParams.get("changes");
  if (changes !== null) {
    if (!/^\d{1,15}$/.test(changes)) return fail("无效的同步位置。");
    const result = await env.DB.prepare(
      "SELECT c.seq, c.entry_id AS changedId, e.id, e.author, e.kind, e.happened_at AS happenedAt, e.detail, e.note, e.weight, e.media, e.revision, " +
      "e.medicine_name AS medicineName, e.medicine_dose AS medicineDose, e.medicine_method AS medicineMethod, " +
      "e.next_medication_at AS nextMedicationAt, e.updated_at AS updatedAt, e.updated_by AS updatedBy " +
      "FROM entry_changes c LEFT JOIN entries e ON e.id = c.entry_id WHERE c.seq > ? ORDER BY c.seq LIMIT 50",
    ).bind(Number(changes)).all();
    const entries = [];
    const deleted = [];
    for (const { seq, changedId, ...row } of result.results) {
      if (row.id) entries.push(parseEntry(row));
      else deleted.push(changedId);
    }
    return json({ entries, deleted, changeCursor: result.results.at(-1)?.seq ?? Number(changes) });
  }
  const after = url.searchParams.get("after");
  if (after !== null) {
    if (!/^\d{1,15}$/.test(after)) return fail("无效的同步位置。");
    const result = await env.DB.prepare(entryQuery.replace("SELECT id", "SELECT rowid AS seq, id") +
      " WHERE rowid > ? ORDER BY rowid LIMIT 50").bind(Number(after)).all();
    const cursor = result.results.at(-1)?.seq ?? Number(after);
    return json({ entries: result.results.map(({ seq, ...row }) => parseEntry(row)), cursor });
  }
  const before = url.searchParams.get("before");
  const order = " ORDER BY happened_at DESC, id DESC LIMIT 51";
  let result;
  let cursor = null;
  let changeCursor = null;
  if (before) {
    const [date, id, extra] = before.split("|");
    if (extra !== undefined || !validId.test(id) || !Number.isFinite(Date.parse(date))) return fail("无效的分页位置。");
    result = await env.DB.prepare(entryQuery + " WHERE (happened_at, id) < (?, ?)" + order).bind(date, id).all();
  } else {
    const head = await env.DB.prepare(
      "SELECT COALESCE(MAX(rowid), 0) AS seq, (SELECT COALESCE(MAX(seq), 0) FROM entry_changes) AS changeSeq FROM entries",
    ).first();
    cursor = head.seq;
    changeCursor = head.changeSeq;
    result = await env.DB.prepare(entryQuery + order).all();
  }
  const entries = result.results.slice(0, 50).map(parseEntry);
  const last = entries.at(-1);
  return json({ entries, cursor, changeCursor, next: result.results.length > 50 ? last.happenedAt + "|" + last.id : null });
}

function parseRange(value, size) {
  const match = /^bytes=(\d*)-(\d*)$/.exec(value);
  if (!match || (!match[1] && !match[2])) return null;
  const start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
  const end = match[1] && match[2] ? Math.min(size - 1, Number(match[2])) : size - 1;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start > end) return null;
  return { offset: start, length: end - start + 1 };
}

async function getMedia(request, env, entryId, fileId, url) {
  const row = await env.DB.prepare("SELECT author, media FROM entries WHERE id = ?").bind(entryId).first();
  const file = row && JSON.parse(row.media).find(item => item.id === fileId);
  if (!file) return fail("附件不存在。", 404);
  const rangeHeader = request.headers.get("range");
  const range = rangeHeader && parseRange(rangeHeader, file.size);
  if (rangeHeader && !range) {
    return new Response(null, { status: 416, headers: { ...privateHeaders, "Content-Range": "bytes */" + file.size } });
  }
  const headers = {
    ...privateHeaders,
    "Content-Type": file.type,
    "Content-Length": String(range ? range.length : file.size),
    "Accept-Ranges": "bytes",
  };
  if (range) headers["Content-Range"] = "bytes " + range.offset + "-" + (range.offset + range.length - 1) + "/" + file.size;
  if (url.searchParams.has("download")) {
    const safeName = encodeURIComponent(file.name || "attachment").replace(/['()]/g, character => "%" + character.charCodeAt(0).toString(16));
    headers["Content-Disposition"] = "attachment; filename*=UTF-8''" + safeName;
  }
  if (request.method === "HEAD") return new Response(null, { headers });
  const object = await env.BUCKET.get(storageKey(row.author, entryId, fileId, file.uploadRevision), range ? { range } : undefined);
  if (!object) return fail("附件不存在。", 404);
  return new Response(object.body, { status: range ? 206 : 200, headers });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const { pathname } = url;
    const method = request.method;
    if (!pathname.startsWith("/api/")) {
      const asset = pathname === "/" ? ["html", "text/html"] : pathname === "/style.css" ? ["css", "text/css"] :
        pathname === "/app.js" ? ["js", "text/javascript"] : null;
      if (!asset || (method !== "GET" && method !== "HEAD")) return new Response("Not found", { status: 404 });
      const body = pathname === "/" && url.searchParams.get("preview") === "phone" ?
        assets.html.replace('<html lang="zh-CN">', '<html lang="zh-CN" class="phone-preview">') :
        assets[asset[0]];
      return new Response(method === "HEAD" ? null : body, {
        headers: {
          ...privateHeaders,
          "Content-Type": asset[1] + "; charset=utf-8",
          "Content-Security-Policy": "default-src 'self'; img-src 'self' blob:; media-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
          "X-Robots-Tag": "noindex, nofollow",
        },
      });
    }

    try {
      if (method !== "GET" && method !== "HEAD" && request.headers.get("origin") !== url.origin) {
        return fail("请从日记页面重试。", 403);
      }
      if (pathname === "/api/session" && method === "POST") {
        const data = await readJson(request);
        const access = typeof data?.key === "string" && accessFor(data.key, env);
        if (!access) return fail("日记链接无效，请检查你打开的链接。", 401);
        return json({ author: access === "shared" ? null : access }, 200, {
          "Set-Cookie": COOKIE + "=" + data.key + "; Max-Age=2592000; Path=/; Secure; HttpOnly; SameSite=Strict",
        });
      }

      const cookies = request.headers.get("cookie") || "";
      const key = cookies.split(";").map(part => part.trim()).find(part => part.startsWith(COOKIE + "="))?.slice(COOKIE.length + 1);
      const access = accessFor(key, env);
      if (!access) return fail("请从日记的共用链接或专属链接打开。", 401);
      if (pathname === "/api/zhuzhu-head.png" && (method === "GET" || method === "HEAD")) {
        const bytes = method === "HEAD" ? null : Uint8Array.from(atob(assets.head), byte => byte.charCodeAt(0));
        return new Response(bytes, {
          headers: { ...privateHeaders, "Content-Type": "image/png" },
        });
      }
      if (pathname === "/api/session" && method === "GET") return json({ author: access === "shared" ? null : access });
      if (pathname === "/api/entries" && method === "GET") return await listEntries(env, url);
      const entry = entryRoute.exec(pathname);
      if (entry && (method === "PATCH" || method === "DELETE")) {
        const actor = request.headers.get("X-Care-Author") ?? access;
        if (actor !== "owner" && actor !== "friend") return fail("请选择汤圆爸或汤圆妈。");
        return await changeEntry(request, env, entry[1], actor);
      }

      const file = mediaRoute.exec(pathname);
      const adding = pathname === "/api/entries" && method === "POST";
      if (adding || (file && method === "PUT")) {
        // Attribute each write to the identity chosen in that tab, including every attachment.
        const author = request.headers.get("X-Care-Author") ?? access;
        if (author !== "owner" && author !== "friend") return fail("请选择汤圆爸或汤圆妈。");
        if (adding) return await createEntry(request, env, author);
        return await upload(request, env, author, file[1], file[2]);
      }
      if (file && (method === "GET" || method === "HEAD")) return await getMedia(request, env, file[1], file[2], url);
      return fail("找不到这个页面。", 404);
    } catch (error) {
      console.error(error?.name || "Request error", pathname);
      return fail("暂时无法处理，请稍后重试。", 500);
    }
  },
};
