const types = {
  food:      ["饮食", "🍚", "吃了什么", "食物、饮水、分量和吃了多少"],
  medicine:  ["用药", "💊", "用了什么药", "药名、实际用量、用法，或是否吐出"],
  urine:     ["尿尿", "💧", "尿尿情况", "次数、大概的量、颜色或有没有费力"],
  stool:     ["便便", "💩", "便便情况", "次数、形态、颜色或其他观察"],
  condition: ["状态", "🌿", "她今天怎么样", "精神、活动、睡眠、呕吐或其他变化"],
  weight:    ["体重", "⚖️", "称重情况", "例如饭前称重，选填"],
  visit:     ["就诊", "🏥", "就诊情况", "医院、检查结果、医嘱或复诊时间"],
  other:     ["其他", "📝", "想记下什么", "写下其他需要留意的事情"],
};
const authorNames = { owner: "汤圆妈", friend: "汤圆爸" };
const authorPreference = "tangyuan-journal-author";
const draftPreference = "tangyuan-journal-draft-v2-";
const formats = new Set([
  "image/jpeg", "image/png", "image/webp", "image/gif", "image/heic", "image/heif", "image/avif",
  "video/mp4", "video/quicktime", "video/webm", "video/x-m4v",
]);
const fallbackTypes = {
  jpg:"image/jpeg", jpeg:"image/jpeg", png:"image/png", webp:"image/webp", gif:"image/gif",
  heic:"image/heic", heif:"image/heif", avif:"image/avif", mp4:"video/mp4",
  mov:"video/quicktime", webm:"video/webm", m4v:"video/x-m4v",
};
const $ = id => document.getElementById(id);
const entries = new Map();
const deletedEntries = new Set();
let kind = "food";
let author = null;
let draftId = crypto.randomUUID();
let draftAuthor = null;
let files = [];
let editing = null;
let newDraft = null;
let saving = false;
let initialized = false;
let fetching = false;
let next = null;
let cursor = null;
let filter = "";
let draftTimer = null;

const localDate = new Intl.DateTimeFormat("sv-SE", { dateStyle: "short", timeStyle: "short", timeZone: "Asia/Shanghai" });
const displayDate = new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "long", day: "numeric", weekday: "short", timeZone: "Asia/Shanghai" });
const displayTime = new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit", hourCycle: "h23", timeZone: "Asia/Shanghai" });
function linkKey() {
  const fragment = location.hash.slice(1);
  if (/^[A-Za-z0-9_-]{22}$/.test(fragment)) return fragment;
  return new URLSearchParams(fragment).get("key");
}

function node(tag, classes, text) {
  const el = document.createElement(tag);
  if (classes) el.className = classes;
  if (text) el.textContent = text;
  return el;
}

function api(path, options) {
  return fetch(path, { ...options, cache: "no-store" }).then(async response => {
    let body;
    try { body = await response.json(); } catch { body = null; }
    if (!response.ok || !body) {
      const error = new Error(body?.error || "连接暂时不可用，请重试。");
      error.status = response.status;
      throw error;
    }
    return body;
  });
}

function send(path, data, headers = {}, method = "POST") {
  return api(path, { method, headers: { "Content-Type": "application/json", ...headers }, body: JSON.stringify(data) });
}

function selectKind(id) {
  kind = id;
  $("categories").querySelector('input[value="' + id + '"]').checked = true;
  $("detail-label").textContent = types[id][2];
  $("detail").placeholder = types[id][3];
  $("weight-field").hidden = id !== "weight";
  $("weight").required = id === "weight";
  $("medication-fields").hidden = id !== "medicine";
  $("detail-field").hidden = id === "medicine" || id === "weight";
  renderPreviousMedication();
  scheduleDraft();
}

for (const [id, [name, emoji]] of Object.entries(types)) {
  const label = node("label", "category");
  const input = node("input", "sr-only");
  input.type = "radio";
  input.name = "kind";
  input.value = id;
  input.checked = id === kind;
  input.addEventListener("change", () => selectKind(id));
  const icon = node("span", "", emoji);
  icon.setAttribute("aria-hidden", "true");
  label.append(input, icon, node("span", "", name));
  $("categories").append(label);
}
selectKind(kind);

function latestMedication() {
  return [...entries.values()].filter(entry => entry.kind === "medicine")
    .sort((a, b) => b.happenedAt.localeCompare(a.happenedAt))[0] ?? null;
}

function renderPreviousMedication() {
  const row = latestMedication();
  $("previous-medication").textContent = row ?
    "上次 " + displayTime.format(new Date(row.happenedAt)) + " · " + authorNames[row.author] +
      (row.medicineName ? " · " + row.medicineName : "") + (row.medicineDose ? " " + row.medicineDose : "") :
    "还没有用药记录";
}

function displayHappened() {
  const [date, time] = $("happened").value.split("T");
  if (!time) {
    $("happened-display").textContent = "选择日期和时间";
    return;
  }
  $("happened-display").textContent = date.replaceAll("-", ".") + " " + time.slice(0, 5);
}

function displayNextMedication() {
  const [date, time] = $("next-medication").value.split("T");
  $("next-medication-display").textContent = time ?
    date.replaceAll("-", ".") + " " + time.slice(0, 5) : "选择日期和时间";
}

function setHappened(value = localDate.format(new Date()).replace(" ", "T")) {
  $("happened").value = value;
  displayHappened();
}

$("happened").addEventListener("input", displayHappened);
$("happened").addEventListener("change", displayHappened);
$("happened").addEventListener("click", event => {
  if (getComputedStyle($("happened-display")).display !== "none") {
    try { event.currentTarget.showPicker?.(); } catch {}
  }
});
$("next-medication").addEventListener("input", displayNextMedication);
$("next-medication").addEventListener("change", displayNextMedication);
$("next-medication").addEventListener("click", event => {
  try { event.currentTarget.showPicker?.(); } catch {}
});
setHappened();
displayNextMedication();

function draftKey(role = author) {
  return draftPreference + role;
}

function draftData() {
  return {
    id: draftId,
    kind,
    happened: $("happened").value,
    detail: $("detail").value,
    note: $("note").value,
    weight: $("weight").value,
    medicineName: $("medicine-name").value,
    medicineDose: $("medicine-dose").value,
    medicineMethod: $("medicine-method").value,
    nextMedication: $("next-medication").value,
  };
}

function persistDraft() {
  if (!author || editing || saving) return;
  try { localStorage.setItem(draftKey(), JSON.stringify(draftData())); } catch {}
}

function scheduleDraft() {
  if (!author || editing || saving) return;
  clearTimeout(draftTimer);
  draftTimer = setTimeout(persistDraft, 250);
}

function restoreDraft() {
  if (!author || editing) return;
  let data;
  try { data = JSON.parse(localStorage.getItem(draftKey()) || "null"); } catch { data = null; }
  if (!data || !Object.hasOwn(types, data.kind)) return;
  draftId = typeof data.id === "string" ? data.id : crypto.randomUUID();
  draftAuthor = author;
  selectKind(data.kind);
  $("detail").value = data.detail || "";
  $("note").value = data.note || "";
  $("weight").value = data.weight || "";
  $("medicine-name").value = data.medicineName || "";
  $("medicine-dose").value = data.medicineDose || "";
  $("medicine-method").value = data.medicineMethod || "";
  $("next-medication").value = data.nextMedication || "";
  displayNextMedication();
  if (data.happened) setHappened(data.happened);
}

function clearDraft() {
  clearTimeout(draftTimer);
  try { localStorage.removeItem(draftKey()); } catch {}
}

function resetDraftForm() {
  draftId = crypto.randomUUID();
  draftAuthor = null;
  files = [];
  $("detail").value = "";
  $("note").value = "";
  $("weight").value = "";
  $("medicine-name").value = "";
  $("medicine-dose").value = "";
  $("medicine-method").value = "";
  $("next-medication").value = "";
  displayNextMedication();
  setHappened();
  selectKind("food");
  showSelected();
}

for (const control of $("entry-form").querySelectorAll("input, textarea")) {
  control.addEventListener("input", scheduleDraft);
  control.addEventListener("change", scheduleDraft);
}

function formStatus(message, problem = false) {
  $("form-status").textContent = message;
  $("form-status").classList.toggle("problem", problem);
}

function showSelected() {
  const rows = files.map((item, index) => {
    const name = item.file?.name || item.name || "附件";
    const row = node("li");
    const remove = node("button", "remove", "移除");
    remove.type = "button";
    remove.disabled = saving;
    remove.setAttribute("aria-label", "移除 " + name);
    remove.addEventListener("click", () => {
      files.splice(index, 1);
      showSelected();
      formStatus("");
    });
    row.append(node("span", "", name), remove);
    return row;
  });
  $("selected-files").replaceChildren(...rows);
}

function openEditor(entry) {
  if (saving) return;
  if (editing && editing.id !== entry.id) {
    formStatus("请先保存或取消当前修改。", true);
  } else if (!editing) {
    newDraft = {
      kind, files, happened: $("happened").value, detail: $("detail").value,
      note: $("note").value, weight: $("weight").value,
      medicineName: $("medicine-name").value, medicineDose: $("medicine-dose").value,
      medicineMethod: $("medicine-method").value, nextMedication: $("next-medication").value,
    };
    editing = entry;
    selectKind(entry.kind);
    files = entry.media.map(file => ({ ...file, uploaded: true }));
    $("detail").value = entry.detail;
    $("note").value = entry.note;
    $("weight").value = entry.weight ?? "";
    $("medicine-name").value = entry.medicineName ?? "";
    $("medicine-dose").value = entry.medicineDose ?? "";
    $("medicine-method").value = entry.medicineMethod ?? "";
    $("next-medication").value = entry.nextMedicationAt ?
      localDate.format(new Date(entry.nextMedicationAt)).replace(" ", "T") : "";
    displayNextMedication();
    setHappened(localDate.format(new Date(entry.happenedAt)).replace(" ", "T"));
    $("compose-title").textContent = "修改记录";
    $("compose-copy").textContent = "这条记录最初由" + authorNames[entry.author] + "保存。";
    $("cancel-edit").hidden = false;
    showSelected();
    formStatus("");
  }
  $("compose-title").scrollIntoView({ block: "start" });
}

function closeEditor() {
  if (!editing) return;
  selectKind(newDraft.kind);
  files = newDraft.files;
  $("detail").value = newDraft.detail;
  $("note").value = newDraft.note;
  $("weight").value = newDraft.weight;
  $("medicine-name").value = newDraft.medicineName;
  $("medicine-dose").value = newDraft.medicineDose;
  $("medicine-method").value = newDraft.medicineMethod;
  $("next-medication").value = newDraft.nextMedication;
  displayNextMedication();
  setHappened(newDraft.happened);
  editing = null;
  newDraft = null;
  $("compose-title").textContent = "记一条";
  $("compose-copy").textContent = "记录刚刚发生的事，也可以补记。";
  $("cancel-edit").hidden = true;
  showSelected();
  formStatus("");
}

$("cancel-edit").addEventListener("click", closeEditor);

function acceptEntry(entry) {
  if (deletedEntries.has(entry.id)) return;
  const existing = entries.get(entry.id);
  if (!existing || (entry.revision ?? 0) >= (existing.revision ?? 0)) entries.set(entry.id, entry);
}

function forgetEntry(id) {
  deletedEntries.add(id);
  entries.delete(id);
}

async function deleteRecord(row, button) {
  if (saving || button.disabled || !confirm("删除这条记录及其附件？")) return;
  button.disabled = true;
  try {
    await send("/api/entries/" + row.id, { revision: row.revision }, { "X-Care-Author": author }, "DELETE");
    forgetEntry(row.id);
    if (editing?.id === row.id) closeEditor();
    render();
    syncStatus("已删除");
  } catch (error) {
    if (error.status === 404) { forgetEntry(row.id); render(); }
    if (error.status === 409) await sync(false, true);
    syncStatus(error.message, true);
  } finally {
    button.disabled = false;
  }
}

async function optimizePhoto(file, type) {
  if (!["image/jpeg", "image/png", "image/webp"].includes(type) || file.size < 1024 * 1024) return { file, type };
  try {
    const image = await createImageBitmap(file);
    const scale = Math.min(1, 2000 / Math.max(image.width, image.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.width * scale));
    canvas.height = Math.max(1, Math.round(image.height * scale));
    canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
    image.close();
    const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", .84));
    if (!blob || blob.size >= file.size) return { file, type };
    const name = file.name.replace(/\.[^.]+$/, "") + ".jpg";
    return { file: new File([blob], name, { type: "image/jpeg", lastModified: file.lastModified }), type: "image/jpeg" };
  } catch {
    return { file, type };
  }
}

$("files").addEventListener("change", async event => {
  const notices = new Set();
  const selectedFiles = [...event.target.files];
  event.target.value = "";
  if (selectedFiles.some(file => file.type.startsWith("image/"))) formStatus("正在优化照片…");
  for (const original of selectedFiles) {
    let file = original;
    const guessed = fallbackTypes[file.name.split(".").at(-1).toLowerCase()];
    let type = formats.has(file.type) ? file.type : guessed;
    if (files.length >= 4) { notices.add("每条记录最多添加 4 个附件。"); break; }
    if (!type) { notices.add("有文件格式不受支持。"); continue; }
    if (!file.size) { notices.add("请重新选择有效的附件。"); continue; }
    ({ file, type } = await optimizePhoto(file, type));
    const photo = type.startsWith("image/");
    const maxMB = photo ? 10 : 25;
    if (file.size > maxMB * 1024 * 1024) {
      notices.add(photo ? "照片每张不超过 10 MB。" : "视频每个不超过 25 MB。");
      continue;
    }
    files.push({ file, type, id: crypto.randomUUID(), uploaded: false });
  }
  showSelected();
  formStatus([...notices].join(" "), notices.size > 0);
});

function paw() {
  const icon = node("span", "paw");
  icon.setAttribute("aria-hidden", "true");
  for (let index = 0; index < 4; index++) icon.append(node("i"));
  icon.append(node("b"));
  return icon;
}

function attachment(entry, file) {
  const figure = node("figure", "attachment");
  const url = "/api/media/" + entry.id + "/" + file.id;
  const link = node("a", "", (file.type.startsWith("video/") ? "打开视频" : "打开照片") + (file.name ? " · " + file.name : ""));
  link.href = url;
  link.target = "_blank";
  link.rel = "noopener";
  const video = file.type.startsWith("video/");
  const media = node(video ? "video" : "img");
  media.src = url;
  if (video) {
    media.controls = true;
    media.playsInline = true;
    media.preload = "metadata";
  } else {
    media.loading = "lazy";
    media.alt = file.name || "记录照片";
  }
  media.addEventListener("error", () => {
    media.hidden = true;
    link.href = url + "?download=1";
    link.textContent = "下载附件" + (file.name ? " · " + file.name : "");
  });
  figure.append(media, link);
  return figure;
}

function localDay(date) {
  return localDate.format(date).slice(0, 10);
}

let rendered = "";
function render() {
  const chosen = filter;
  renderPreviousMedication();
  const rows = [...entries.values()].filter(entry => !chosen || chosen === entry.kind).sort((a, b) =>
    b.happenedAt.localeCompare(a.happenedAt) || b.id.localeCompare(a.id));
  $("more").hidden = !next;
  const key = initialized + "|" + author + "|" + chosen + "|" + rows.map(row => row.id + ":" + row.revision).join(",");
  if (key === rendered) return;
  rendered = key;
  const content = $("entries");
  if (!rows.length) {
    const empty = node("div", "empty");
    empty.append(paw(), node("strong", "", !initialized ? "正在读取记录" : chosen ? "暂时没有符合条件的记录" : "还没有记录"));
    content.replaceChildren(empty);
    return;
  }
  const oldCards = new Map([...content.querySelectorAll(".record")].map(card => [card.dataset.id, card]));
  const output = document.createDocumentFragment();
  let day = "";
  for (const row of rows) {
    const date = new Date(row.happenedAt);
    const currentDay = displayDate.format(date).replace(/日\s*(?=周|星期)/, "日 ");
    if (currentDay !== day) output.append(node("h3", "day", currentDay));
    day = currentDay;
    const attribution = displayTime.format(date) + " · " + authorNames[row.author] + (author === row.author ? "（你）" : "");
    const oldCard = oldCards.get(row.id);
    if (oldCard?.dataset.revision === String(row.revision)) {
      oldCard.querySelector(".record-meta").textContent = attribution;
      output.append(oldCard);
      continue;
    }
    const card = node("article", "record");
    card.dataset.id = row.id;
    card.dataset.revision = String(row.revision);
    const head = node("div", "record-head");
    const [name, emoji] = types[row.kind];
    head.append(node("span", "badge", emoji + " " + name), node("span", "record-meta", attribution));
    card.append(head);
    if (row.weight !== null) card.append(node("p", "record-detail", row.weight + " kg"));
    if (row.kind === "medicine" && (row.medicineName || row.medicineDose || row.medicineMethod)) {
      const medication = node("dl", "medication-detail");
      for (const [label, value] of [["药名", row.medicineName], ["剂量", row.medicineDose], ["方式", row.medicineMethod]]) {
        if (value) medication.append(node("dt", "", label), node("dd", "", value));
      }
      if (row.nextMedicationAt) {
        medication.append(node("dt", "", "下次"), node("dd", "", localDate.format(new Date(row.nextMedicationAt)).replaceAll("-", ".")));
      }
      card.append(medication);
    }
    if (row.detail) card.append(node("p", "record-detail", row.detail));
    if (row.note) card.append(node("p", "record-note", "备注 · " + row.note));
    if (row.revision > 1 && row.updatedBy) {
      card.append(node("p", "record-edited", authorNames[row.updatedBy] + "修改 · " +
        localDate.format(new Date(row.updatedAt)).replaceAll("-", ".")));
    }
    if (row.media.length) {
      const list = node("div", "media-list");
      list.append(...row.media.map(file => attachment(row, file)));
      card.append(list);
    }
    if (row.revision) {
      const actions = node("div", "record-actions");
      const editButton = node("button", "", "修改");
      const deleteButton = node("button", "danger", "删除");
      editButton.type = deleteButton.type = "button";
      editButton.addEventListener("click", () => openEditor(row));
      deleteButton.addEventListener("click", () => deleteRecord(row, deleteButton));
      actions.append(editButton, deleteButton);
      card.append(actions);
    }
    output.append(card);
  }
  content.replaceChildren(output);
}

function syncStatus(message, problem = false) {
  $("sync").textContent = message;
  $("sync").classList.toggle("problem", problem);
}

async function sync(loadPast = false, quiet = false) {
  if (!author || fetching) return;
  fetching = true;
  if (!quiet) syncStatus("正在同步…");
  $("more").disabled = true;
  $("refresh").disabled = true;
  try {
    const initial = cursor === null;
    const query = loadPast ? "?before=" + encodeURIComponent(next) : initial ? "" : "?changes=" + cursor;
    const page = await api("/api/entries" + query);
    for (const id of page.deleted ?? []) forgetEntry(id);
    for (const entry of page.entries) acceptEntry(entry);
    if (loadPast || initial) next = page.next;
    if (!loadPast) cursor = page.changeCursor ?? null;
    initialized = true;
    render();
    syncStatus("已同步");
  } catch (error) {
    syncStatus(error.status === 401 ? "连接已过期，请重新打开专属链接" : "同步失败，可点刷新重试", true);
  } finally {
    $("more").disabled = false;
    $("refresh").disabled = false;
    fetching = false;
  }
}

const filterControl = $("filter-control");
const filterToggle = $("filter-toggle");
const filterOptions = $("filter-options");
const choices = [["", "类型"], ...Object.entries(types).map(([id, [name]]) => [id, name])];
const filterButtons = choices.map(([id, label]) => {
  const button = node("button", "", label);
  button.type = "button";
  button.dataset.filter = id;
  button.setAttribute("aria-pressed", String(id === filter));
  return button;
});
filterOptions.append(...filterButtons);

function setFilterOpen(open) {
  filterOptions.hidden = !open;
  filterToggle.setAttribute("aria-expanded", String(open));
  if (open) filterButtons.find(button => button.dataset.filter === filter).focus();
}

filterToggle.addEventListener("click", () => setFilterOpen(filterOptions.hidden));
filterOptions.addEventListener("click", event => {
  const button = event.target.closest("button[data-filter]");
  if (!button) return;
  filter = button.dataset.filter;
  $("filter-label").textContent = filter ? button.textContent : "类型";
  for (const option of filterButtons) option.setAttribute("aria-pressed", String(option === button));
  setFilterOpen(false);
  filterToggle.focus();
  render();
});
filterControl.addEventListener("keydown", event => {
  if (event.key === "Escape" && !filterOptions.hidden) {
    event.preventDefault();
    setFilterOpen(false);
    filterToggle.focus();
    return;
  }
  const direction = event.key === "ArrowDown" ? 1 : event.key === "ArrowUp" ? -1 : 0;
  if (!direction) return;
  event.preventDefault();
  if (filterOptions.hidden) {
    setFilterOpen(true);
  } else {
    const index = filterButtons.indexOf(document.activeElement);
    const nextIndex = (index + direction + filterButtons.length) % filterButtons.length;
    filterButtons[nextIndex].focus();
  }
});
filterControl.addEventListener("focusout", event => {
  if (event.relatedTarget && !filterControl.contains(event.relatedTarget)) setFilterOpen(false);
});
document.addEventListener("pointerdown", event => {
  if (!filterOptions.hidden && !filterControl.contains(event.target)) setFilterOpen(false);
});
$("refresh").addEventListener("click", () => sync());
$("more").addEventListener("click", () => { if (next) sync(true); });
document.addEventListener("visibilitychange", () => { if (!document.hidden) sync(false, true); });
setInterval(() => { if (!document.hidden && navigator.onLine) sync(false, true); }, 6000);

$("entry-form").addEventListener("submit", async event => {
  event.preventDefault();
  if (saving || !author) return;
  const detail = $("detail-field").hidden && editing?.kind !== kind ? "" : $("detail").value.trim();
  const note = $("note").value.trim();
  const weight = kind === "weight" ? $("weight").valueAsNumber : null;
  const medicineName = kind === "medicine" ? $("medicine-name").value.trim() : "";
  const medicineDose = kind === "medicine" ? $("medicine-dose").value.trim() : "";
  const medicineMethod = kind === "medicine" ? $("medicine-method").value.trim() : "";
  const nextMedicationValue = kind === "medicine" ? $("next-medication").value : "";
  if (!detail && !note && weight === null && !medicineName && !medicineDose && !medicineMethod && !files.length) {
    formStatus("请填写记录内容，或添加照片、视频。", true);
    return;
  }
  const time = new Date($("happened").value + "+08:00");
  if (!Number.isFinite(time.valueOf())) { formStatus("请选择有效的发生时间。", true); return; }
  if (!editing && draftAuthor && draftAuthor !== author) {
    draftId = crypto.randomUUID();
    for (const file of files) file.uploaded = false;
  }
  if (!editing) draftAuthor = author;
  const actorHeaders = { "X-Care-Author": author };
  const entryId = editing?.id ?? draftId;
  const nextMedication = nextMedicationValue ? new Date(nextMedicationValue + "+08:00") : null;
  if (nextMedication && !Number.isFinite(nextMedication.valueOf())) {
    formStatus("请选择有效的下次用药时间。", true);
    return;
  }
  const data = {
    id: entryId, kind, detail, note, weight, happenedAt: time.toISOString(), files: files.map(file => file.id),
    medicineName, medicineDose, medicineMethod, nextMedicationAt: nextMedication?.toISOString() ?? null,
  };
  if (editing) data.revision = editing.revision;
  const uploadHeaders = editing ? { ...actorHeaders, "X-Entry-Revision": String(editing.revision) } : actorHeaders;
  saving = true;
  const controls = [$("identity-choice"), ...$("entry-form").querySelectorAll("input, textarea, button")];
  for (const control of controls) control.disabled = true;
  formStatus("正在保存…");
  try {
    for (const [index, item] of files.entries()) {
      if (item.uploaded) continue;
      formStatus("正在上传附件 " + (index + 1) + " / " + files.length + "…");
      await api("/api/media/" + entryId + "/" + item.id, {
        method: "PUT",
        headers: { ...uploadHeaders, "Content-Type": item.type, "X-File-Name": encodeURIComponent(item.file.name.slice(0, 150)) },
        body: item.file,
      });
      item.uploaded = true;
    }
    formStatus("正在保存记录…");
    const result = editing ?
      await send("/api/entries/" + entryId, data, actorHeaders, "PATCH") :
      await send("/api/entries", data, actorHeaders);
    if (result.entry) {
      acceptEntry(result.entry);
      initialized = true;
      render();
    }
    if (editing) {
      closeEditor();
      formStatus("修改已保存。");
    } else {
      $("detail").value = "";
      $("note").value = "";
      $("weight").value = "";
      $("medicine-name").value = "";
      $("medicine-dose").value = "";
      $("medicine-method").value = "";
      $("next-medication").value = "";
      displayNextMedication();
      setHappened();
      files = [];
      clearDraft();
      draftId = crypto.randomUUID();
      draftAuthor = null;
      formStatus("已保存。对方打开日记后就能看到。");
    }
    await sync(false, true);
  } catch (error) {
    formStatus(error.message, true);
    if (editing && (error.status === 404 || error.status === 409)) await sync(false, true);
  } finally {
    saving = false;
    for (const control of controls) control.disabled = false;
    showSelected();
  }
});

function rememberedAuthor() {
  try { return localStorage.getItem(authorPreference); } catch { return null; }
}

function chooseAuthor(role) {
  if (saving || !Object.hasOwn(authorNames, role)) return;
  const previousAuthor = author;
  if (previousAuthor && previousAuthor !== role) persistDraft();
  const open = !$("journal").hidden;
  author = role;
  $("identity-choice").value = role;
  try { localStorage.setItem(authorPreference, role); } catch {}
  $("gate").hidden = true;
  $("journal").hidden = false;
  if (previousAuthor && previousAuthor !== role) resetDraftForm();
  if (!open || author !== draftAuthor) restoreDraft();
  rendered = "";
  render();
  if (!open) sync();
}

$("identity-choice").addEventListener("change", event => chooseAuthor(event.target.value));
$("identity-options").addEventListener("click", event => {
  const button = event.target.closest("[data-author]");
  if (!button) return;
  chooseAuthor(button.dataset.author);
  $("identity-choice").focus();
});

async function connect() {
  $("gate-title").textContent = "正在打开日记";
  $("gate-text").textContent = "正在确认你的访问权限…";
  $("retry").hidden = true;
  try {
    const key = linkKey();
    const session = key ? await send("/api/session", { key }) : await api("/api/session");
    document.body.classList.add("journal-open");
    if (key) history.replaceState(null, "", location.pathname + location.search);
    $("identity").hidden = false;
    const selected = key && session.author ? session.author : rememberedAuthor() || session.author;
    if (Object.hasOwn(authorNames, selected)) {
      chooseAuthor(selected);
    } else {
      $("gate-title").textContent = "选一下你是谁";
      $("gate-text").textContent = "保存时会标明记录人，也可以在右上角随时切换。";
      $("identity-options").hidden = false;
    }
  } catch (error) {
    $("gate-title").textContent = error.status === 401 ? "请打开日记的访问链接" : "暂时打不开日记";
    $("gate-text").textContent = error.message;
    $("retry").hidden = error.status === 401;
  }
}
$("retry").addEventListener("click", connect);
window.addEventListener("hashchange", () => {
  if (linkKey()) location.reload();
});
connect();
