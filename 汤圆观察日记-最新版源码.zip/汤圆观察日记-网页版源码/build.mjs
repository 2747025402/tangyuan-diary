import { readFile, writeFile, mkdir, copyFile } from "node:fs/promises";
import { createHash } from "node:crypto";

const read = (path) => readFile(new URL(path, import.meta.url), "utf8");
const [server, html, css, js, head] = await Promise.all([
  read("./worker/index.mjs"),
  read("./web/index.html"),
  read("./web/style.css"),
  read("./web/app.js"),
  readFile(new URL("./web/zhuzhu-head.png", import.meta.url)),
]);
await mkdir("dist/server", { recursive: true });
await mkdir("dist/.openai", { recursive: true });
const version = content => createHash("sha256").update(content).digest("hex").slice(0, 16);
const page = html.replace("/style.css", "/style.css?v=" + version(css))
  .replace("/app.js", "/app.js?v=" + version(js));
const assets = JSON.stringify({html: page, css, js, head: head.toString("base64")});
await writeFile("dist/server/index.js", "const assets = " + assets + ";\n" + server);
await copyFile(".openai/hosting.json", "dist/.openai/hosting.json");
await import(new URL("data:text/javascript;base64," +
  Buffer.from("const assets = " + assets + ";\n" + server).toString("base64")));
