CREATE TABLE entries (
  id text PRIMARY KEY NOT NULL,
  author text NOT NULL,
  kind text NOT NULL,
  happened_at text NOT NULL,
  created_at text NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  detail text NOT NULL,
  note text NOT NULL,
  weight real,
  media text NOT NULL
);
--> statement-breakpoint
CREATE INDEX entries_timeline_idx ON entries (happened_at DESC, id DESC);
