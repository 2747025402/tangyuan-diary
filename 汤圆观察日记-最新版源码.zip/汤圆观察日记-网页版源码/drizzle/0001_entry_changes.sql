ALTER TABLE entries ADD COLUMN revision integer NOT NULL DEFAULT 1;
--> statement-breakpoint
CREATE TABLE entry_changes (
  seq integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  entry_id text NOT NULL UNIQUE
);
--> statement-breakpoint
CREATE TRIGGER entries_notify_insert AFTER INSERT ON entries BEGIN
  INSERT OR REPLACE INTO entry_changes (entry_id) VALUES (NEW.id);
END;
--> statement-breakpoint
CREATE TRIGGER entries_notify_update AFTER UPDATE ON entries BEGIN
  INSERT OR REPLACE INTO entry_changes (entry_id) VALUES (NEW.id);
END;
--> statement-breakpoint
CREATE TRIGGER entries_notify_delete AFTER DELETE ON entries BEGIN
  INSERT OR REPLACE INTO entry_changes (entry_id) VALUES (OLD.id);
END;
