ALTER TABLE entries ADD COLUMN medicine_name text;
--> statement-breakpoint
ALTER TABLE entries ADD COLUMN medicine_dose text;
--> statement-breakpoint
ALTER TABLE entries ADD COLUMN medicine_method text;
--> statement-breakpoint
ALTER TABLE entries ADD COLUMN next_medication_at text;
--> statement-breakpoint
ALTER TABLE entries ADD COLUMN updated_at text;
--> statement-breakpoint
ALTER TABLE entries ADD COLUMN updated_by text;
